import { LastParamPipe } from './last-param.pipe';

describe('LastParamPipe', () => {
  it('create an instance', () => {
    const pipe = new LastParamPipe();
    expect(pipe).toBeTruthy();
  });
});
